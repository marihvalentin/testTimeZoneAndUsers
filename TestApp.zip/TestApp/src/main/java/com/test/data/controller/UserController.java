package com.test.data.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;

import com.test.data.model.User;
import com.test.data.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("")
public class UserController {
	
	@Autowired
	private UserRepository userRepository;
	
	@RequestMapping(path="/data")
	public String date(HttpServletRequest request) {
		String timeZone= request.getParameter("timeZone");

		Calendar GMTZone = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		long gmtTime = GMTZone.getTime().getTime();
		long TZAlteredTime = gmtTime + TimeZone.getTimeZone(timeZone).getRawOffset();

		Calendar TMZone = Calendar.getInstance(TimeZone.getTimeZone(timeZone));
		TMZone.setTimeInMillis(TZAlteredTime + 10800000);
		Date alteredDate =TMZone.getTime();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		
		return dateFormat.format(alteredDate);
	}

	@GetMapping(path="/user/add")
	@ResponseStatus
	public User add(HttpServletRequest request) {
		Long id = Long.parseLong(request.getParameter("ID"));
		String nome = request.getParameter("Nome");
		String nascimento = request.getParameter("Nascimento");
		double salario = Double.parseDouble(request.getParameter("Salário"));

		User user = new User(id, nome, nascimento, salario);

		return userRepository.save(user);
	}

	@GetMapping("/user/consult")
	public List<User> consult() {

		return userRepository.findAll();
	}
}
